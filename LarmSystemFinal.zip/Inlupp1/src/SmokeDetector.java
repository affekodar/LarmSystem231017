import java.util.ArrayList;

public class SmokeDetector extends Detectors {
    SmokeDetector() {
    }

    ArrayList<Detectors> smokeDetectorList = new ArrayList<>();

    ArrayList<Detectors> setSmokeDetectors() {
        Room room = new Room();

        for (int i = 0; i < room.getSmokeList().size(); i++) {
            SmokeDetector smoke = new SmokeDetector();
            smoke.setDetectorID("SD " + room.getSmokeList().get(i));
            smoke.setState(false);
            smokeDetectorList.add(smoke);
        }
        return smokeDetectorList;
    }

    public ArrayList<Detectors> getSmokeDetectorList() {
        return smokeDetectorList;
    }

    public void setSmokeDetectorList(ArrayList<Detectors> smokeDetectorList) {
        this.smokeDetectorList = smokeDetectorList;
    }
}
