public abstract class Detectors {
    public Detectors() {
    }

    private String detectorID;
    private boolean state;

    public boolean getState() {
        return state;
    }

    public void setState(boolean state) {
        this.state = state;
    }

    public String getDetectorID() {
        return detectorID;
    }

    public void setDetectorID(String detectorID) {
        this.detectorID = detectorID;
    }

    public String toString() {
        if (getState())
            return getDetectorID() + " has been set off, needs reset";
        else
            return getDetectorID() + " ready";
    }

    void alarmActive() {
        System.out.println("*BEEP* " + getDetectorID() + " has been set off! Investigate. Needs RESET.");
        setState(true);
    }
}
