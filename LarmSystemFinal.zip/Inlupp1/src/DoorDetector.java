import java.util.ArrayList;

public class DoorDetector extends Detectors {
    DoorDetector() {
    }

    ArrayList<Detectors> doorDetectorList = new ArrayList<>();

    public ArrayList<Detectors> getDoorDetectorList() {
        return doorDetectorList;
    }

    ArrayList<Detectors> setDoorDetectors() {
        Room room = new Room();
        for (int i = 0; i < room.getDoorList().size(); i++) {
            DoorDetector door = new DoorDetector();
            door.setDetectorID("DD " + room.getDoorList().get(i));
            door.setState(false);
            doorDetectorList.add(door);
        }
        return doorDetectorList;
    }

    public void setDoorDetectorList(ArrayList<Detectors> doorDetectorList) {
        this.doorDetectorList = doorDetectorList;
    }
}
