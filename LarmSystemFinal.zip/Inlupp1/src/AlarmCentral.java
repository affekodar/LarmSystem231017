import javax.swing.*;
import java.util.Timer;
import java.util.TimerTask;

public class AlarmCentral {

    private boolean systemOn;

    void getMainMenu() {
        System.out.println("1. Activate alarm\n"
                + "2. Deactivate alarm\n"
                + "3. Simulate alarm\n"
                + "4. Status for detectors \n"
                + "5. RESET all detectors\n"
                + "6. Exit\n"
                + "Select a choice from the menu: ");

    }

    void getSimulationMenu() {
        System.out.println("1. Simulate fire alarm\n"
                + "2. Simulate window breaking/opening alarm\n"
                + "3. Simulate door opening alarm\n"
                + "4. Simulate motion detection alarm\n"
                + "5. Perform randomized simulation\n"
                + "6. Simulate opening a door with codebox\n"
                + "7. Exit to main menu");
    }

    void getDetectorMenu() {
        System.out.println("1. Show status system\n"
                + "2. Show smoke detector status\n"
                + "3. Show window detector status\n"
                + "4. Show door detector status\n"
                + "5. Show motion detector status\n"
                + "6. Show status for all detectors\n"
                + "7. Exit to main menu\n");
    }

    void codeBox() {
        int tries = 0;

        do {
            int code;
            JFrame f;
            f = new JFrame();
            f.setAlwaysOnTop(true);
            code = Integer.parseInt(JOptionPane.showInputDialog(f, "Enter Code"));
            if (code == 1234) {
                System.out.println("The alarm is now activated");
                systemOn = true;
            } else {
                tries++;
                System.out.println("Wrong code!!Try again!");
                systemOn = false;
            }
            if (tries == 3)
                System.out.println("BEWARE! This is your last try to type in the right code or the alarm will go off!");
            if (tries > 3) {
                System.out.println("*Alarm sounding* You have typed the wrong code too many times and the alarm is now sounding. Call 01234567 to verify and turn siren off.");
            }
        } while (!systemOn && tries < 4);
    }

    void codeBoxTimer() {

        JFrame f;
        int code;
        java.util.Timer timer = new java.util.Timer();
        java.util.Timer timer2 = new java.util.Timer();
        do {
            timer.schedule(new TimerTask() {
                int i = 10;

                @Override
                public void run() {
                    System.out.println(i);
                    i--;
                }
            }, 100, 1000);
            timer2.schedule(new TimerTask() {
                @Override
                public void run() {
                    System.out.println("*Alarm sounding* A door next to a codebox has been opened without disabling the alarm. ");
                    timer.cancel();
                    timer2.cancel();
                }
            }, 10000L);
            f = new JFrame();
            f.setAlwaysOnTop(true);
            f.setLocationRelativeTo(null);
            code = Integer.parseInt(JOptionPane.showInputDialog(f, "Enter Code"));
            if (code == 1234) {
                System.out.println("The alarm has been disabled");
                timer.cancel();
                timer2.cancel();
            } else {
                System.out.println("Wrong code!!Try again!");
            }
        } while (code != 1234);
    }

    void exitTimer(int minutes) {
        java.util.Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                System.exit(0);
            }
        }, minutes * 60000L);
    }

    public boolean isSystemOn() {
        return systemOn;
    }

    public void setSystemOn(boolean alarmOn) {
        this.systemOn = alarmOn;
    }

}
