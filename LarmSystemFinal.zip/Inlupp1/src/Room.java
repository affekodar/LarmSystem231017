import java.util.ArrayList;

public class Room {
    private boolean hasWindow;
    private int numberOfDoors;
    private String roomName;

    Room() {
    }

    Room(String roomName, int numberOfDoors, boolean hasWindow) {
        this.roomName = roomName;
        this.hasWindow = hasWindow;
        this.numberOfDoors = numberOfDoors;
    }

    Room(String roomName, boolean hasWindow) {
        this.roomName = roomName;
        this.hasWindow = hasWindow;
    }

    public boolean isHasWindow() {
        return hasWindow;
    }

    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    public String getRoomName() {
        return roomName;
    }

    public Room[] setRoomList() {
        Room[] roomList = new Room[10];
        roomList[0] = new Room("Bedroom 1", 1, true);
        roomList[1] = new Room("Bedroom 2", 1, true);
        roomList[2] = new Room("Bedroom 3", 1, true);
        roomList[3] = new Room("Bedroom 4", 2, true);
        roomList[4] = new Room("Bedroom 5", 1, true);
        roomList[5] = new Room("Garage", 1, true);
        roomList[6] = new Room("Kitchen", true);
        roomList[7] = new Room("Hallway", 1, true);
        roomList[8] = new Room("Garden", false);
        roomList[9] = new Room("Living Room", 2, true);
        return roomList;
    }

    public ArrayList<String> getSmokeList() {
        ArrayList<String> smokeList = new ArrayList<>();
        for (Room room : setRoomList())
            if (!room.getRoomName().equals("Garden")) {
                smokeList.add(room.getRoomName());
            }
        return smokeList;
    }

    public ArrayList<String> getDoorList() {
        ArrayList<String> doorList = new ArrayList<>();
        for (Room room : setRoomList()) {
            if (room.getNumberOfDoors() != 0) {
                doorList.add(room.getRoomName());
            }
        }
        return doorList;
    }

    public ArrayList<String> getWindowList() {
        ArrayList<String> windowList = new ArrayList<>();
        for (Room room : setRoomList()) {
            if (room.isHasWindow()) {
                windowList.add(room.getRoomName());
            }
        }
        return windowList;
    }

    public String getMotionDetector() {
        return "Garden";
    }
}
