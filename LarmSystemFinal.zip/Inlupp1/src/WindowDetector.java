import java.util.ArrayList;

public class WindowDetector extends Detectors {
    WindowDetector() {
    }

    ArrayList<Detectors> windowDetectorList = new ArrayList<>();

    ArrayList<Detectors> setWindowDetectors() {
        Room room = new Room();
        for (int i = 0; i < room.getSmokeList().size(); i++) {
            WindowDetector window = new WindowDetector();
            window.setDetectorID("WD " + room.getWindowList().get(i));
            window.setState(false);
            windowDetectorList.add(window);
        }
        return windowDetectorList;
    }

    public ArrayList<Detectors> getWindowDetectorList() {
        return windowDetectorList;
    }

    public void setWindowDetectorList(ArrayList<Detectors> windowDetectorList) {
        this.windowDetectorList = windowDetectorList;
    }
}
