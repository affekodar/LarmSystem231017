

import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
//        alarm.exitTimer(1);

        AlarmCentral alarm = new AlarmCentral();
        Room room = new Room();

        SmokeDetector smoke = new SmokeDetector();
        WindowDetector window = new WindowDetector();
        DoorDetector door = new DoorDetector();
        door.setDoorDetectors();
        smoke.setSmokeDetectors();
        window.setWindowDetectors();

        MotionDetector motion = new MotionDetector();
        motion.setDetectorID("MD " + room.getMotionDetector());
        motion.setState(false);


        ArrayList<Detectors> detList = new ArrayList<>();
        detList.addAll(smoke.getSmokeDetectorList());
        detList.addAll(door.getDoorDetectorList());
        detList.addAll(window.getWindowDetectorList());
        detList.add(motion);


        int userInput;
        do {
            System.out.println();
            System.out.println("---------------------------------");
            alarm.getMainMenu();
            userInput = scanner.nextInt();

            while (userInput < 1 || userInput > 6) {
                System.out.println("\nError! Not a valid choice");
                alarm.getMainMenu();
                userInput = scanner.nextInt();
            }
            switch (userInput) {
                case 1 -> alarm.codeBox();
                case 2 -> {
                    System.out.println("The alarm is now deactivated.");
                    alarm.setSystemOn(false);
                }
                case 3 -> {
                    alarm.getSimulationMenu();
                    int simulationInput = scanner.nextInt();
                    while (simulationInput < 1 || simulationInput > 7) {
                        System.out.println("\nError! Not a valid choice");
                        alarm.getSimulationMenu();
                        simulationInput = scanner.nextInt();
                    }

                    switch (simulationInput) {
                        case 1 -> {
                            int randomSmoke = random.nextInt(smoke.smokeDetectorList.size());
                            smoke.getSmokeDetectorList().get(randomSmoke).setState(true);
                            smoke.getSmokeDetectorList().get(randomSmoke).alarmActive();
                        }
                        case 2 -> {
                            int randomWindow = random.nextInt(window.windowDetectorList.size());
                            window.getWindowDetectorList().get(randomWindow).setState(true);
                            window.getWindowDetectorList().get(randomWindow).alarmActive();
                        }
                        case 3 -> {
                            int randomDoor = random.nextInt(door.doorDetectorList.size());
                            door.getDoorDetectorList().get(randomDoor).setState(true);
                            door.getDoorDetectorList().get(randomDoor).alarmActive();
                        }
                        case 4 -> {
                            motion.setState(true);
                            motion.alarmActive();
                        }
                        case 5 -> {
                            int randomAlarm = random.nextInt(4) + 1;
                            switch (randomAlarm) {
                                case 1 -> {
                                    int randomSmoke = random.nextInt(smoke.setSmokeDetectors().size());
                                    smoke.getSmokeDetectorList().get(randomSmoke).setState(true);
                                    smoke.getSmokeDetectorList().get(randomSmoke).alarmActive();
                                }
                                case 2 -> {
                                    int randomWindow = random.nextInt(window.setWindowDetectors().size());
                                    window.setWindowDetectors().get(randomWindow).setState(true);
                                    window.setWindowDetectors().get(randomWindow).alarmActive();
                                }
                                case 3 -> {
                                    int randomDoor = random.nextInt(door.setDoorDetectors().size());
                                    door.setDoorDetectors().get(randomDoor).setState(true);
                                    door.setDoorDetectors().get(randomDoor).alarmActive();
                                }
                                case 4 -> {
                                    motion.setState(true);
                                    motion.alarmActive();
                                }
                            }
                        }
                        case 6 -> {
                            System.out.println("Input 4-digit code to disable alarm or it will go off in 10 seconds!!");
                            alarm.codeBoxTimer();
                        }
                        case 7 -> {
                        }
                    }
                }
                case 4 -> {
                    alarm.getDetectorMenu();
                    int detInput = scanner.nextInt();
                    while (detInput < 1 || detInput > 7) {
                        System.out.println("\nError! Not a valid choice");
                        alarm.getSimulationMenu();
                        detInput = scanner.nextInt();
                    }
                    switch (detInput) {
                        case 1 -> {
                            if (alarm.isSystemOn())
                                System.out.println("The alarm system is ON.");
                            else
                                System.out.println("The alarm system is OFF.");
                        }
                        case 2 -> {
                            System.out.println("Status for smoke detectors: ");
                            for (int i = 0; i < smoke.getSmokeDetectorList().size(); i++) {
                                System.out.println(smoke.getSmokeDetectorList().get(i).toString());
                            }
                        }
                        case 3 -> {
                            System.out.println("Status for window detectors: ");
                            for (int i = 0; i < window.getWindowDetectorList().size(); i++) {
                                System.out.println(window.getWindowDetectorList().get(i).toString());
                            }
                        }
                        case 4 -> {
                            System.out.println("Status for door detectors: ");
                            for (int i = 0; i < door.getDoorDetectorList().size(); i++) {
                                System.out.println(door.getDoorDetectorList().get(i).toString());
                            }
                        }
                        case 5 -> {
                            System.out.println("Status for garden motion detector: ");
                            System.out.println(motion.toString());
                        }
                        case 6 -> {
                            System.out.println("Status for all detectors: ");
                            for (Detectors detectors : detList) {
                                System.out.println(detectors.toString());
                            }
                        }
                        case 7 -> {
                        }
                    }
                }
                case 5 -> {
                    for (Detectors detectors : detList) {
                        detectors.setState(false);
                    }
                }
                case 6 -> System.exit(0);
            }
        } while (true);
    }
}