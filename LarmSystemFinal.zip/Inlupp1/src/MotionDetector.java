
public class MotionDetector extends Detectors {
    MotionDetector() {
    }
}
